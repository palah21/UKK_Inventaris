<?php
require_once '../dompdf/autoload.inc.php';  // pastikan path ini sesuai dengan lokasi Dompdf
use Dompdf\Dompdf;
use Dompdf\Options;

// Koneksi database
require_once '../config/db.php';

// Inisialisasi Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isPhpEnabled', true);
$dompdf = new Dompdf($options);

// Ambil data barang yang akan diekspor
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

// SQL query untuk mengambil data barang
$sql = "SELECT barang.*, kategori.nama_kategori FROM barang 
        LEFT JOIN kategori ON barang.kategori_id = kategori.id
        WHERE barang.nama_barang LIKE '%$keyword%'";

if ($filter_kategori != '') {
    $sql .= " AND barang.kategori_id = $filter_kategori";
}

$result = mysqli_query($koneksi, $sql);

// Membuat HTML untuk ditampilkan dalam PDF
$html = '
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <h2>Data Barang</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Tanggal Masuk</th>
            </tr>
        </thead>
        <tbody>';

        $no = 1;
while ($barang = mysqli_fetch_assoc($result)) {
    $html .= '
            <tr>
                <td>' . $no++ . '</td>
                <td>' . $barang['nama_barang'] . '</td>
                <td>' . $barang['nama_kategori'] . '</td>
                <td>' . $barang['jumlah_stok'] . '</td>
                <td>Rp' . number_format($barang['harga_barang'], 0, ',', '.') . '</td>
                <td>' . $barang['tanggal_masuk'] . '</td>
            </tr>';
}

$html .= '
        </tbody>
    </table>
</body>
</html>';

// Load HTML ke Dompdf
$dompdf->loadHtml($html);

// Set ukuran kertas
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Set header yang tepat untuk menampilkan file di browser
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=data_barang.pdf");
header("Content-Transfer-Encoding: binary");
header("Accept-Ranges: bytes");

// Output PDF ke browser
echo $dompdf->output();
exit;
