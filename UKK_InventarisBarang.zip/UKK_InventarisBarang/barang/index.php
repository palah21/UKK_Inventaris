<?php 
include '../config/db.php';
include '../sidebar.php';

// -- Proses Pencarian & Filter --
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

// Pagination
$limit = 5; // jumlah data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Hitung total data
$countQuery = "SELECT COUNT(*) as total FROM barang 
               WHERE nama_barang LIKE '%$keyword%'";
if ($filter_kategori != '') {
    $countQuery .= " AND kategori_id = $filter_kategori";
}
$countResult = mysqli_query($koneksi, $countQuery);
$totalData = mysqli_fetch_assoc($countResult)['total'];
$totalPages = ceil($totalData / $limit);

// Ambil data barang dengan limit
$sql = "SELECT barang.*, kategori.nama_kategori FROM barang 
        LEFT JOIN kategori ON barang.kategori_id = kategori.id
        WHERE barang.nama_barang LIKE '%$keyword%'";
if ($filter_kategori != '') {
    $sql .= " AND barang.kategori_id = $filter_kategori";
}
$sql .= " ORDER BY barang.id DESC LIMIT $limit OFFSET $offset";
$result = mysqli_query($koneksi, $sql);

// Ambil data kategori untuk filter dropdown
$kategori_result = mysqli_query($koneksi, "SELECT * FROM kategori");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Barang</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

<div class="max-w-7xl mx-auto px-4 py-8">
  <h2 class="text-2xl font-semibold mb-6">📦 Data Barang</h2>

  <!-- Notifikasi CRUD -->
  <?php if (isset($_GET['pesan'])): ?>
    <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
      <?= $_GET['pesan'] ?>
    </div>
  <?php endif; ?>

  <!-- Form Pencarian & Filter -->
  <form method="get" class="grid md:grid-cols-3 gap-4 mb-6">
    <input type="text" name="keyword" class="p-2 border rounded shadow-sm w-full" placeholder="Cari nama barang..." value="<?= $keyword ?>">

    <select name="kategori" class="p-2 border rounded shadow-sm w-full">
      <option value="">-- Semua Kategori --</option>
      <?php while ($row = mysqli_fetch_assoc($kategori_result)) { ?>
        <option value="<?= $row['id'] ?>" <?= ($row['id'] == $filter_kategori) ? 'selected' : '' ?>>
          <?= $row['nama_kategori'] ?>
        </option>
      <?php } ?>
    </select>

    <div class="flex gap-2">
      <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Cari</button>
      <a href="tambah.php" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">+ Tambah</a>
      <a href="export.php?keyword=<?= $keyword ?>&kategori=<?= $filter_kategori ?>" 
   target="_blank" 
   class="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded">
   Export
</a>
    </div>
  </form>

  <!-- Tabel Data Barang -->
  <div class="overflow-x-auto bg-white rounded-xl shadow p-4">
    <table class="min-w-full table-auto border text-sm">
      <thead class="bg-gray-200 text-gray-700">
        <tr>
          <th class="px-4 py-2 text-left">Nama Barang</th>
          <th class="px-4 py-2 text-left">Kategori</th>
          <th class="px-4 py-2 text-left">Stok</th>
          <th class="px-4 py-2 text-left">Harga</th>
          <th class="px-4 py-2 text-left">Tanggal Masuk</th>
          <th class="px-4 py-2 text-left">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($barang = mysqli_fetch_assoc($result)) { ?>
        <tr class="border-b hover:bg-gray-50">
          
          <td class="px-4 border py-2"><?= $barang['nama_barang'] ?></td>
          <td class="px-4 border py-2"><?= $barang['nama_kategori'] ?></td>
          <td class="px-4 border py-2"><?= $barang['jumlah_stok'] ?></td>
          <td class="px-4 border py-2">Rp<?= number_format($barang['harga_barang'],0,',','.') ?></td>
          <td class="px-4 border py-2"><?= $barang['tanggal_masuk'] ?></td>
          <td class="px-4 border py-2">
            <a href="edit.php?id=<?= $barang['id'] ?>" class="text-yellow-600 hover:underline mr-2">Edit</a>
            <a href="hapus.php?id=<?= $barang['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Yakin hapus data?')">Hapus</a>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <div class="mt-6 flex justify-center">
    <ul class="inline-flex -space-x-px text-sm">
      <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
        <li>
          <a href="?keyword=<?= $keyword ?>&kategori=<?= $filter_kategori ?>&page=<?= $i ?>"
             class="px-3 py-2 border <?= ($i == $page) ? 'bg-blue-600 text-white' : 'bg-white text-blue-600' ?> hover:bg-blue-500 hover:text-white transition rounded">
            <?= $i ?>
          </a>
        </li>
      <?php endfor; ?>
    </ul>
  </div>
</div>

</body>
</html>

