<?php
include '../config/db.php';
include '../sidebar.php';

// include '../navbar.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
if (empty($id)) {
    die("ID tidak ditemukan.");
}

$query = "SELECT * FROM kategori WHERE id = $id";
$result = mysqli_query($koneksi, $query);
if (mysqli_num_rows($result) == 0) {
    die("Data kategori tidak ditemukan.");
}
$data = mysqli_fetch_assoc($result);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_kategori = trim($_POST['nama_kategori']);
    $icon = trim($_POST['icon']);
    
    if (empty($nama_kategori)) {
        $errors[] = "Nama kategori tidak boleh kosong.";
    }
    
    if (empty($errors)) {
        $updateQuery = "UPDATE kategori SET nama_kategori = '$nama_kategori', icon = '$icon' WHERE id = $id";
            if (mysqli_query($koneksi, $updateQuery)) {
            header("Location: index.php?pesan=Kategori berhasil diperbarui");
            exit;
        } else {
            $errors[] = "Gagal memperbarui data: " . mysqli_error($koneksi);
        }
    }
} else {
    $nama_kategori = $data['nama_kategori'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Kategori</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

<div class="max-w-xl mx-auto mt-10 bg-white p-6 rounded-xl shadow">
  <h2 class="text-2xl font-semibold mb-6 text-center">✏️ Edit Kategori Barang</h2>

  <?php if (!empty($errors)): ?>
    <div class="bg-red-100 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc list-inside">
      <?php foreach ($errors as $error): ?>
        <li><?= $error ?></li>
      <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post">
    <div class="mb-4">
      <label class="block font-medium mb-1">Nama Kategori</label>
      <input type="text" name="nama_kategori" value="<?= $nama_kategori ?>" class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
    </div>
    
    <div class="flex justify-between items-center mt-6">
      <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow">Perbarui</button>
      <a href="index.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded shadow">Kembali</a>
    </div>
  </form>
</div>
<!-- Import lucide icons -->
<script src="https://unpkg.com/lucide@latest"></script>
<script>
  lucide.createIcons();
</script>
</body>
</html>

</body>
</html>
