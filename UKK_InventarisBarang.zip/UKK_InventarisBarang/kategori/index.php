<?php 
include '../config/db.php';
include '../sidebar.php';

// include '../navbar.php';

$result = mysqli_query($koneksi, "SELECT * FROM kategori");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Kategori</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>

</head>
<body class="bg-gray-100 text-gray-800">

<div class="max-w-4xl mx-auto mt-10 bg-white p-6 rounded-xl shadow">
  <h2 class="text-2xl font-semibold mb-6 text-center">📦 Data Kategori Barang</h2>

  <!-- Notifikasi -->
  <?php if (isset($_GET['pesan'])): ?>
    <div class="bg-green-100 text-green-800 px-4 py-3 rounded mb-4">
      <?= $_GET['pesan'] ?>
    </div>
  <?php endif; ?>

  <!-- Tombol -->
  <div class="flex justify-between mb-4">
    <a href="tambah.php" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow">+ Tambah Kategori</a>
    <a href="../barang/index.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded shadow">Kembali ke Barang</a>
  </div>

  <!-- Tabel -->
  <div class="overflow-x-auto">
    <table class="min-w-full table-auto border border-gray-300 text-sm">
      <thead class="bg-gray-200 text-gray-700">
        <tr>
          <th class="px-4 py-2 border">ID</th>
          <th class="px-4 py-2 border">Nama Kategori</th>
          <th class="px-4 py-2 border">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($kategori = mysqli_fetch_assoc($result)) { ?>
          <tr class="hover:bg-gray-50">
            <td class="px-4 py-2 border text-center"><?= $kategori['id'] ?></td>
            <td class="px-4 py-2 border"><?= $kategori['nama_kategori'] ?></td>
            <td class="px-4 py-2 border text-center">
              <a href="edit.php?id=<?= $kategori['id'] ?>" class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded text-sm mr-1">Edit</a>
              <a href="hapus.php?id=<?= $kategori['id'] ?>" onclick="return confirm('Yakin hapus kategori ini?')" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">Hapus</a>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>

