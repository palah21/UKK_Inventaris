<!-- sidebar.php -->

<div class="flex min-h-screen">
  <aside class="w-64 bg-white shadow-lg">
    <div class="p-6 flex items-center gap-2 text-2xl font-bold text-blue-600">
      <i data-lucide="package"></i>
      Inventaris
    </div>
    <nav class="flex flex-col gap-2 p-4 text-gray-700 text-sm">
      <a href="../barang/index.php" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-blue-100">
        <i data-lucide="box"></i> Barang
      </a>
      <a href="../kategori/index.php" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-blue-100">
        <i data-lucide="tags"></i> Kategori
      </a>
     
      
    </nav>
  </aside>
  <!-- Import lucide icons -->
<script src="https://unpkg.com/lucide@latest"></script>
<script>
  lucide.createIcons();
</script>
</body>
</html>
<main class="flex-1 p-6">
